package gameCenter;

//Define the two types of players as an Enum
public enum PlayerType {
	Admin,
	Basic
}
